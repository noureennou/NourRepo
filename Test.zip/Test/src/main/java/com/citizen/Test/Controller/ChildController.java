package com.citizen.Test.Controller;

import com.citizen.Test.Model.Child;
import com.citizen.Test.Service.ChildService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/child")
public class ChildController {
@Autowired
    private ChildService childService;
@PostMapping
    public ResponseEntity<Child>createChild(@RequestBody Child child){
Child savedcChild=childService.saveChild(child);
return ResponseEntity.ok(savedcChild);
}
}
