package com.citizen.Test.Service;

import com.citizen.Test.Model.Child;
import com.citizen.Test.Repository.ChildRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ChildService {
    @Autowired
    private ChildRepository childRepository;


    public Child saveChild(Child child) {
        return childRepository.save(child);

    }

    public List<Child> getChild() {
        return childRepository.findAll();
    }






}





