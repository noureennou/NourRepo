package com.citizen.Test.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDate;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Table(name=" child_Details")
public class Child {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
private int id;
    @NotNull(message = "Name Cannot be Null")
   private String childName;
private String address;
@Size(min=10,max=10)
private String phnNo;
@Past(message = " Date of birth should be a past date")
private LocalDate dateOfBirth;

}
